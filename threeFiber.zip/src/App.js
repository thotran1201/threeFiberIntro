import "./styles.css";
import ThreeTest from "./ThreeTest/ThreeTest";

export default function App() {
  return (
    <div className="App">
      <ThreeTest />
    </div>
  );
}
